package testblinkm;

import net.sf.smbt.blinkm.cmd.injection.BlinkMUtil;
import net.sf.smbt.comm.topology.utils.TopologyUtils.COMM_PROTOCOL;
import net.sf.smbt.quantic.warp.QuanticMojo;
import net.sf.xqz.engine.utils.AbstractTTLJob;
import net.sf.xqz.model.engine.CmdEngine;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.equinox.app.IApplication;
import org.eclipse.equinox.app.IApplicationContext;

public class BlinkMApp implements IApplication {

	@Override
	public Object start(IApplicationContext context) throws Exception {
		CmdEngine pipeUSB = QuanticMojo.INSTANCE.openUsbPipe(COMM_PROTOCOL.THINGM, "pipeUSB", "/dev/tty.usbserial-A7006022", 19200);

		pipeUSB.send(BlinkMUtil.INSTANCE.createStopScriptCmd("0x00"));
		Thread.sleep(500);
		pipeUSB.send(BlinkMUtil.INSTANCE.createFadeToRGBColorCmd("0x00", 255, 0, 0));
		Thread.sleep(500);
		pipeUSB.send(BlinkMUtil.INSTANCE.createFadeToRGBColorCmd("0x00", 0, 255, 0));
		Thread.sleep(500);
		pipeUSB.send(BlinkMUtil.INSTANCE.createFadeToRGBColorCmd("0x00", 0, 0, 255));
		Thread.sleep(500);

		AbstractTTLJob ttl = new AbstractTTLJob(5000) {
			@Override
			protected IStatus run(IProgressMonitor monitor) {
				schedule(500);
				return Status.OK_STATUS;
			}
		};
		ttl.schedule();
		
		return new Object();
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub

	}

}
